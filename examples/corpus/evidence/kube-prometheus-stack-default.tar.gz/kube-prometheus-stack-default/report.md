# KubeProof evaluation

- Evaluation: `6ecc2b41-96eb-4ee5-8ee1-0e8ec6c5da77`
- Chart: `/home/calogero/kubernetes_production_readiness_lab/examples/corpus/charts/kube-prometheus-stack-91.4.1.tgz`
- Requested version: `unspecified`
- Resolved chart version: `91.4.1`
- Profile: `enterprise-strict`
- Local admission: `static_only`
- Adoption blockers: **42**
- Warnings: **104**

## Check summary

| Check | Execution | Assessment |
|---|---|---|
| Static security and RBAC | `completed` | `fail` |
| Declared resources | `completed` | `fail` |
| Declared availability | `completed` | `fail` |
| Declared external endpoints | `completed` | `warning` |
| Installation and readiness | `completed` | `not_tested` |
| Observed resource consumption | `completed` | `not_tested` |
| Pod replacement readiness | `completed` | `not_tested` |
| Observed network and DNS behavior | `completed` | `not_tested` |

## Local safety admission

Rendered workloads request host-dangerous features that local kind does not safely isolate; runtime execution is prohibited.

Matched rules: `KP-SAFE-002`, `KP-SAFE-003`, `KP-SAFE-005`

## Findings

### [BLOCKER] Workload requests host network

The rendered Pod specification sets hostNetwork: true.

- Evidence: `obs-00001`
- Constraint: `constraints.security.allow_host_network`

### [BLOCKER] Workload requests host PID namespace

The rendered Pod specification sets hostPID: true.

- Evidence: `obs-00002`
- Constraint: `constraints.security.allow_host_pid`

### [BLOCKER] Host filesystem mount requested

The rendered Pod specification declares a hostPath volume.

- Evidence: `obs-00003`
- Constraint: `constraints.security.allow_host_path`

### [BLOCKER] Host filesystem mount requested

The rendered Pod specification declares a hostPath volume.

- Evidence: `obs-00004`
- Constraint: `constraints.security.allow_host_path`

### [BLOCKER] Host filesystem mount requested

The rendered Pod specification declares a hostPath volume.

- Evidence: `obs-00005`
- Constraint: `constraints.security.allow_host_path`

### [BLOCKER] Writable root filesystem is permitted

The container does not explicitly set readOnlyRootFilesystem: true.

- Evidence: `obs-00006`
- Constraint: `constraints.security.require_read_only_root_filesystem`

### [BLOCKER] Writable root filesystem is permitted

The container does not explicitly set readOnlyRootFilesystem: true.

- Evidence: `obs-00007`
- Constraint: `constraints.security.require_read_only_root_filesystem`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00013`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00013`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00013`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00013`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00014`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00014`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00014`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00014`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00015`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00015`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00015`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00015`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00016`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00017`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00018`
- Constraint: `constraints.reliability.minimum_replicas`

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00019`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00020`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00021`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references pushover.net, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00022`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references open.rocket.chat, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00023`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.slack.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00024`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references sns.us-east-2.amazonaws.com., while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00025`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.telegram.org., while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00026`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references webexapis.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00027`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00028`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00029`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00030`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00031`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00032`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references qyapi.weixin.qq.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00033`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tools.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00034`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00035`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references examples.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00036`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references developer.mozilla.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00037`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00038`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00039`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00040`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00041`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00042`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00043`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00044`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00045`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00046`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00047`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00048`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00049`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references learn.microsoft.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00050`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tip.golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00051`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references examples.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00052`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references developer.mozilla.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00053`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00054`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00055`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00056`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00057`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00058`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references learn.microsoft.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00059`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tip.golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00060`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00061`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references thanos.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00062`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references examples.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00063`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references developer.mozilla.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00064`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00065`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00066`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00067`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00068`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00069`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00070`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00071`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.microsoft.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00072`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references learn.microsoft.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00073`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.consul.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00074`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references developer.hashicorp.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00075`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.docker.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00076`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.aws.amazon.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00077`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references cloud.google.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00078`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references nomad.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00079`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.ovh.com., while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00080`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references puppet.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00081`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references console.scaleway.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00082`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00083`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00084`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00085`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00086`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00087`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00088`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00089`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references prometheus.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00090`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00091`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references thanos.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00092`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00093`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references learn.microsoft.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00094`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references examples.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00095`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references developer.mozilla.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00096`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubeproof-target-kube-prom-prometheus.kubeproof-product, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00097`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubeproof-target-kube-prom-alertmanager.kubeproof-product, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00098`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references coredns.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00099`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubeproof-target-kube-prom-alertmanager.kubeproof-product, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00100`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubeproof-target-kube-prom-prometheus.kubeproof-product, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00101`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00102`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.robustperception.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00103`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00104`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00105`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00106`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00107`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00108`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00109`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00110`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00111`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00112`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00113`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00114`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00115`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00116`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00117`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00118`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00119`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00120`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references runbooks.prometheus-operator.dev, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00121`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.robustperception.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00122`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

## Observation index

- `obs-00001` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter — Workload requests the host network.
- `obs-00002` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter — Workload requests the host PID namespace.
- `obs-00003` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter — Workload declares a hostPath volume.
- `obs-00004` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter — Workload declares a hostPath volume.
- `obs-00005` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter — Workload declares a hostPath volume.
- `obs-00006` [static_input] Deployment kubeproof-product/kubeproof-target-grafana (container grafana-sc-dashboard) — Read-only root filesystem is not explicitly enabled.
- `obs-00007` [static_input] Deployment kubeproof-product/kubeproof-target-grafana (container grafana-sc-datasources) — Read-only root filesystem is not explicitly enabled.
- `obs-00008` [static_input] DaemonSet kubeproof-product/kubeproof-target-prometheus-node-exporter (container node-exporter) — Container resource requests and limits were inspected.
- `obs-00009` [static_input] Deployment kubeproof-product/kubeproof-target-grafana (container grafana-sc-dashboard) — Container resource requests and limits were inspected.
- `obs-00010` [static_input] Deployment kubeproof-product/kubeproof-target-grafana (container grafana-sc-datasources) — Container resource requests and limits were inspected.
- `obs-00011` [static_input] Deployment kubeproof-product/kubeproof-target-grafana (container grafana) — Container resource requests and limits were inspected.
- `obs-00012` [static_input] Deployment kubeproof-product/kubeproof-target-kube-state-metrics (container kube-state-metrics) — Container resource requests and limits were inspected.
- `obs-00013` [static_input] Deployment kubeproof-product/kubeproof-target-kube-prom-operator (container kube-prometheus-stack) — Container resource requests and limits were inspected.
- `obs-00014` [static_input] Job kubeproof-product/kubeproof-target-kube-prom-admission-create (container create) — Container resource requests and limits were inspected.
- `obs-00015` [static_input] Job kubeproof-product/kubeproof-target-kube-prom-admission-patch (container patch) — Container resource requests and limits were inspected.
- `obs-00016` [static_input] Deployment kubeproof-product/kubeproof-target-grafana — Deployment replica count was inspected.
- `obs-00017` [static_input] Deployment kubeproof-product/kubeproof-target-kube-state-metrics — Deployment replica count was inspected.
- `obs-00018` [static_input] Deployment kubeproof-product/kubeproof-target-kube-prom-operator — Deployment replica count was inspected.
- `obs-00019` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00020` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00021` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00022` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00023` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00024` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00025` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00026` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00027` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00028` [static_input] CustomResourceDefinition alertmanagerconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00029` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00030` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00031` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00032` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00033` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00034` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00035` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00036` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00037` [static_input] CustomResourceDefinition alertmanagers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00038` [static_input] CustomResourceDefinition podmonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00039` [static_input] CustomResourceDefinition podmonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00040` [static_input] CustomResourceDefinition podmonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00041` [static_input] CustomResourceDefinition podmonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00042` [static_input] CustomResourceDefinition probes.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00043` [static_input] CustomResourceDefinition probes.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00044` [static_input] CustomResourceDefinition probes.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00045` [static_input] CustomResourceDefinition probes.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00046` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00047` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00048` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00049` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00050` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00051` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00052` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00053` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00054` [static_input] CustomResourceDefinition prometheusagents.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00055` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00056` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00057` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00058` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00059` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00060` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00061` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00062` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00063` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00064` [static_input] CustomResourceDefinition prometheuses.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00065` [static_input] CustomResourceDefinition prometheusrules.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00066` [static_input] CustomResourceDefinition prometheusrules.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00067` [static_input] CustomResourceDefinition prometheusrules.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00068` [static_input] CustomResourceDefinition prometheusrules.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00069` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00070` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00071` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00072` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00073` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00074` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00075` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00076` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00077` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00078` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00079` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00080` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00081` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00082` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00083` [static_input] CustomResourceDefinition scrapeconfigs.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00084` [static_input] CustomResourceDefinition servicemonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00085` [static_input] CustomResourceDefinition servicemonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00086` [static_input] CustomResourceDefinition servicemonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00087` [static_input] CustomResourceDefinition servicemonitors.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00088` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00089` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00090` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00091` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00092` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00093` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00094` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00095` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00096` [static_input] CustomResourceDefinition thanosrulers.monitoring.coreos.com — Rendered configuration contains an external URL.
- `obs-00097` [static_input] ConfigMap kubeproof-product/kubeproof-target-kube-prom-grafana-datasource — Rendered configuration contains an external URL.
- `obs-00098` [static_input] ConfigMap kubeproof-product/kubeproof-target-kube-prom-grafana-datasource — Rendered configuration contains an external URL.
- `obs-00099` [static_input] ConfigMap kubeproof-product/kubeproof-target-kube-prom-k8s-coredns — Rendered configuration contains an external URL.
- `obs-00100` [static_input] Alertmanager kubeproof-product/kubeproof-target-kube-prom-alertmanager — Rendered configuration contains an external URL.
- `obs-00101` [static_input] Prometheus kubeproof-product/kubeproof-target-kube-prom-prometheus — Rendered configuration contains an external URL.
- `obs-00102` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-alertmanager.rules — Rendered configuration contains an external URL.
- `obs-00103` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-alertmanager.rules — Rendered configuration contains an external URL.
- `obs-00104` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-config-reloaders — Rendered configuration contains an external URL.
- `obs-00105` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-etcd — Rendered configuration contains an external URL.
- `obs-00106` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-general.rules — Rendered configuration contains an external URL.
- `obs-00107` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kube-apiserver-slos — Rendered configuration contains an external URL.
- `obs-00108` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kube-state-metrics — Rendered configuration contains an external URL.
- `obs-00109` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-apps — Rendered configuration contains an external URL.
- `obs-00110` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-resources — Rendered configuration contains an external URL.
- `obs-00111` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-storage — Rendered configuration contains an external URL.
- `obs-00112` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system-apiserver — Rendered configuration contains an external URL.
- `obs-00113` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system-controller-manager — Rendered configuration contains an external URL.
- `obs-00114` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system-kube-proxy — Rendered configuration contains an external URL.
- `obs-00115` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system-kubelet — Rendered configuration contains an external URL.
- `obs-00116` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system-scheduler — Rendered configuration contains an external URL.
- `obs-00117` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-kubernetes-system — Rendered configuration contains an external URL.
- `obs-00118` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-node-exporter — Rendered configuration contains an external URL.
- `obs-00119` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-node-network — Rendered configuration contains an external URL.
- `obs-00120` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-prometheus-operator — Rendered configuration contains an external URL.
- `obs-00121` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-prometheus — Rendered configuration contains an external URL.
- `obs-00122` [static_input] PrometheusRule kubeproof-product/kubeproof-target-kube-prom-prometheus — Rendered configuration contains an external URL.
- `obs-00123` [static_input] evaluation — Rendered input was inspected for security and RBAC.
- `obs-00124` [static_input] evaluation — Rendered input was inspected for declared resources.
- `obs-00125` [static_input] evaluation — Rendered input was inspected for declared availability.
- `obs-00126` [static_input] evaluation — Rendered input was inspected for declared endpoints.

## Scope limitations

This bundle contains static rendered-input observations only. Runtime checks shown as `not_tested` did not run.
A static URL or observed DNS query is not proof of a required network dependency. An absent security-context field is not proof of the image's runtime UID.
