# KubeProof evaluation

- Evaluation: `b9dd915c-4db7-4b8a-8ccf-b9ee2d474960`
- Chart: `/home/calogero/kubernetes_production_readiness_lab/examples/corpus/charts/cert-manager-v1.21.2.tgz`
- Requested version: `unspecified`
- Resolved chart version: `v1.21.2`
- Profile: `enterprise-strict`
- Local admission: `admit`
- Adoption blockers: **19**
- Warnings: **0**

## Check summary

| Check | Execution | Assessment |
|---|---|---|
| Static security and RBAC | `completed` | `pass` |
| Declared resources | `completed` | `fail` |
| Declared availability | `completed` | `fail` |
| Declared external endpoints | `completed` | `pass` |
| Installation and readiness | `completed` | `not_tested` |
| Observed resource consumption | `completed` | `not_tested` |
| Pod replacement readiness | `completed` | `not_tested` |
| Observed network and DNS behavior | `completed` | `not_tested` |

## Local safety admission

No v0.1 hard-stop feature was found. This permits only known, intentionally selected products and is not hostile-code containment.

## Findings

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00005`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00006`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00007`
- Constraint: `constraints.reliability.minimum_replicas`

## Observation index

- `obs-00001` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-cainjector (container cert-manager-cainjector) — Container resource requests and limits were inspected.
- `obs-00002` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager (container cert-manager-controller) — Container resource requests and limits were inspected.
- `obs-00003` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-webhook (container cert-manager-webhook) — Container resource requests and limits were inspected.
- `obs-00004` [static_input] Job kubeproof-product/kubeproof-target-cert-manager-startupapicheck (container cert-manager-startupapicheck) — Container resource requests and limits were inspected.
- `obs-00005` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-cainjector — Deployment replica count was inspected.
- `obs-00006` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager — Deployment replica count was inspected.
- `obs-00007` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-webhook — Deployment replica count was inspected.
- `obs-00008` [static_input] evaluation — Rendered input was inspected for security and RBAC.
- `obs-00009` [static_input] evaluation — Rendered input was inspected for declared resources.
- `obs-00010` [static_input] evaluation — Rendered input was inspected for declared availability.
- `obs-00011` [static_input] evaluation — Rendered input was inspected for declared endpoints.

## Scope limitations

This bundle contains static rendered-input observations only. Runtime checks shown as `not_tested` did not run.
A static URL or observed DNS query is not proof of a required network dependency. An absent security-context field is not proof of the image's runtime UID.
