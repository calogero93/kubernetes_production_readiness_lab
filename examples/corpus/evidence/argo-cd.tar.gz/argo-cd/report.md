# KubeProof evaluation

- Evaluation: `d4f8da47-9d9b-40e1-b8e9-e620358f2ab7`
- Chart: `/home/calogero/kubernetes_production_readiness_lab/examples/corpus/charts/argo-cd-10.9.1.tgz`
- Requested version: `unspecified`
- Resolved chart version: `10.9.1`
- Profile: `enterprise-strict`
- Local admission: `admit`
- Adoption blockers: **48**
- Warnings: **4**

## Check summary

| Check | Execution | Assessment |
|---|---|---|
| Static security and RBAC | `completed` | `fail` |
| Declared resources | `completed` | `fail` |
| Declared availability | `completed` | `fail` |
| Declared external endpoints | `completed` | `warning` |
| Installation and readiness | `completed` | `pass` |
| Observed resource consumption | `completed` | `pass` |
| Pod replacement readiness | `completed` | `pass` |
| Observed network and DNS behavior | `completed` | `inconclusive` |

## Runtime environment

- Provider: `kind`
- Cluster: `kubeproof-734665d46930`
- Cleanup attempted: `True`
- Cleanup succeeded: `True`


## Local safety admission

No v0.1 hard-stop feature was found. This permits only known, intentionally selected products and is not hostile-code containment.

## Findings

### [BLOCKER] Wildcard RBAC permissions

One or more rendered RBAC rules use wildcard permissions.

- Evidence: `obs-00001`
- Constraint: `constraints.security.allow_wildcard_rbac`
- Possible remediation: Replace wildcard entries with an explicit least-privilege rule set.

### [BLOCKER] Wildcard RBAC permissions

One or more rendered RBAC rules use wildcard permissions.

- Evidence: `obs-00002`
- Constraint: `constraints.security.allow_wildcard_rbac`
- Possible remediation: Replace wildcard entries with an explicit least-privilege rule set.

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00005`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00005`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00005`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00005`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00006`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00006`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00006`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00006`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00007`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00007`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00007`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00007`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00008`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00009`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00010`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00011`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00012`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00013`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00014`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00015`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00016`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00017`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00018`
- Constraint: `constraints.reliability.minimum_replicas`

### [WARNING] Potential external network dependency

Rendered configuration references argocd.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00019`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references argocd.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00020`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00021`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00022`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

## Observation index

- `obs-00001` [static_input] ClusterRole kubeproof-target-argocd-application-controller — RBAC role contains wildcard permissions.
- `obs-00002` [static_input] ClusterRole kubeproof-target-argocd-server — RBAC role contains wildcard permissions.
- `obs-00003` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-applicationset-controller (container applicationset-controller) — Container resource requests and limits were inspected.
- `obs-00004` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-notifications-controller (container notifications-controller) — Container resource requests and limits were inspected.
- `obs-00005` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-repo-server (container repo-server) — Container resource requests and limits were inspected.
- `obs-00006` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-repo-server (container copyutil) — Container resource requests and limits were inspected.
- `obs-00007` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-server (container server) — Container resource requests and limits were inspected.
- `obs-00008` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-dex-server (container dex-server) — Container resource requests and limits were inspected.
- `obs-00009` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-dex-server (container copyutil) — Container resource requests and limits were inspected.
- `obs-00010` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-redis (container redis) — Container resource requests and limits were inspected.
- `obs-00011` [static_input] StatefulSet kubeproof-product/kubeproof-target-argocd-application-controller (container application-controller) — Container resource requests and limits were inspected.
- `obs-00012` [static_input] Job kubeproof-product/kubeproof-target-argocd-redis-secret-init (container secret-init) — Container resource requests and limits were inspected.
- `obs-00013` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-applicationset-controller — Deployment replica count was inspected.
- `obs-00014` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-notifications-controller — Deployment replica count was inspected.
- `obs-00015` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-repo-server — Deployment replica count was inspected.
- `obs-00016` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-server — Deployment replica count was inspected.
- `obs-00017` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-dex-server — Deployment replica count was inspected.
- `obs-00018` [static_input] Deployment kubeproof-product/kubeproof-target-argocd-redis — Deployment replica count was inspected.
- `obs-00019` [static_input] ConfigMap kubeproof-product/argocd-cm — Rendered configuration contains an external URL.
- `obs-00020` [static_input] ConfigMap kubeproof-product/argocd-notifications-cm — Rendered configuration contains an external URL.
- `obs-00021` [static_input] CustomResourceDefinition applications.argoproj.io — Rendered configuration contains an external URL.
- `obs-00022` [static_input] CustomResourceDefinition appprojects.argoproj.io — Rendered configuration contains an external URL.
- `obs-00023` [static_input] evaluation — Rendered input was inspected for security and RBAC.
- `obs-00024` [static_input] evaluation — Rendered input was inspected for declared resources.
- `obs-00025` [static_input] evaluation — Rendered input was inspected for declared availability.
- `obs-00026` [static_input] evaluation — Rendered input was inspected for declared endpoints.
- `runtime-obs-00001` [runtime] evaluation — Helm installation and supported workload readiness were observed.
- `runtime-obs-00002` [runtime] Pod kubeproof-product/kubeproof-target-argocd-application-controller-0 — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00003` [runtime] Pod kubeproof-product/kubeproof-target-argocd-applicationset-controller-7bdddd4fmvlzt — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00004` [runtime] Pod kubeproof-product/kubeproof-target-argocd-notifications-controller-7449d6bcb8ddxm — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00005` [runtime] Pod kubeproof-product/kubeproof-target-argocd-server-64d95bd5bf-bzwkc — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00006` [runtime] Pod kubeproof-product/kubeproof-target-argocd-application-controller-0 — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00007` [runtime] Pod kubeproof-product/kubeproof-target-argocd-applicationset-controller-7bdddd4fmvlzt — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00008` [runtime] Pod kubeproof-product/kubeproof-target-argocd-notifications-controller-7449d6bcb8ddxm — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00009` [runtime] Pod kubeproof-product/kubeproof-target-argocd-redis-74b779fd4d-8dqlp — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00010` [runtime] Pod kubeproof-product/kubeproof-target-argocd-repo-server-56c86b696b-nzbhj — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00011` [runtime] Pod kubeproof-product/kubeproof-target-argocd-server-64d95bd5bf-bzwkc — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00012` [runtime] Pod kubeproof-product/kubeproof-target-argocd-application-controller-0 — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00013` [runtime] Pod kubeproof-product/kubeproof-target-argocd-applicationset-controller-7bdddd4fmvlzt — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00014` [runtime] Pod kubeproof-product/kubeproof-target-argocd-dex-server-5957c4dc67-pv27q — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00015` [runtime] Pod kubeproof-product/kubeproof-target-argocd-notifications-controller-7449d6bcb8ddxm — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00016` [runtime] Pod kubeproof-product/kubeproof-target-argocd-redis-74b779fd4d-8dqlp — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00017` [runtime] Pod kubeproof-product/kubeproof-target-argocd-repo-server-56c86b696b-nzbhj — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00018` [runtime] Pod kubeproof-product/kubeproof-target-argocd-server-64d95bd5bf-bzwkc — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00019` [runtime] Pod kubeproof-product/kubeproof-target-argocd-application-controller-0 — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00020` [runtime] Pod kubeproof-product/kubeproof-target-argocd-applicationset-controller-7bdddd4fmvlzt — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00021` [runtime] Pod kubeproof-product/kubeproof-target-argocd-dex-server-5957c4dc67-pv27q — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00022` [runtime] Pod kubeproof-product/kubeproof-target-argocd-notifications-controller-7449d6bcb8ddxm — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00023` [runtime] Pod kubeproof-product/kubeproof-target-argocd-redis-74b779fd4d-8dqlp — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00024` [runtime] Pod kubeproof-product/kubeproof-target-argocd-repo-server-56c86b696b-nzbhj — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00025` [runtime] Pod kubeproof-product/kubeproof-target-argocd-server-64d95bd5bf-bzwkc — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00026` [runtime] Pod kubeproof-product/kubeproof-target-argocd-application-controller-0 — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00027` [runtime] Pod kubeproof-product/kubeproof-target-argocd-applicationset-controller-7bdddd4fmvlzt — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00028` [runtime] Pod kubeproof-product/kubeproof-target-argocd-dex-server-5957c4dc67-pv27q — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00029` [runtime] Pod kubeproof-product/kubeproof-target-argocd-notifications-controller-7449d6bcb8ddxm — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00030` [runtime] Pod kubeproof-product/kubeproof-target-argocd-redis-74b779fd4d-8dqlp — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00031` [runtime] Pod kubeproof-product/kubeproof-target-argocd-repo-server-56c86b696b-nzbhj — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00032` [runtime] Pod kubeproof-product/kubeproof-target-argocd-server-64d95bd5bf-bzwkc — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00033` [runtime] Deployment kubeproof-product/kubeproof-target-argocd-applicationset-controller — Deployment controller Pod replacement readiness was measured.
- `runtime-obs-00034` [runtime] Deployment kubeproof-product/kubeproof-target-argocd-dex-server — Deployment controller Pod replacement readiness was measured.
- `runtime-obs-00035` [runtime] Deployment kubeproof-product/kubeproof-target-argocd-notifications-controller — Deployment controller Pod replacement readiness was measured.

## Scope limitations

Runtime observations apply only to this disposable cluster and observation window.
A static URL or observed DNS query is not proof of a required network dependency. An absent security-context field is not proof of the image's runtime UID.
