# KubeProof evaluation

- Evaluation: `2a713f04-b4de-4e0e-879e-8c9bfd864e1d`
- Chart: `examples/corpus/charts/cert-manager-v1.21.2.tgz`
- Requested version: `unspecified`
- Resolved chart version: `v1.21.2`
- Profile: `enterprise-strict`
- Local admission: `admit`
- Adoption blockers: **19**
- Warnings: **52**

## Check summary

| Check | Execution | Assessment |
|---|---|---|
| Static security and RBAC | `completed` | `pass` |
| Declared resources | `completed` | `fail` |
| Declared availability | `completed` | `fail` |
| Declared external endpoints | `completed` | `warning` |
| Installation and readiness | `completed` | `pass` |
| Observed resource consumption | `completed` | `pass` |
| Pod replacement readiness | `completed` | `pass` |
| Observed network and DNS behavior | `completed` | `inconclusive` |

## Runtime environment

- Provider: `kind`
- Cluster: `kubeproof-e2efbbc9fa55`
- Cleanup attempted: `True`
- Cleanup succeeded: `True`


## Local safety admission

No v0.1 hard-stop feature was found. This permits only known, intentionally selected products and is not hostile-code containment.

## Findings

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00001`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00002`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00003`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Cpu request is missing

The rendered container has no cpu request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Cpu limit is missing

The rendered container has no cpu limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_cpu_limit_per_pod`

### [BLOCKER] Memory request is missing

The rendered container has no memory request.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.require_requests`

### [BLOCKER] Memory limit is missing

The rendered container has no memory limit; no finite maximum is declared.

- Evidence: `obs-00004`
- Constraint: `constraints.resources.max_memory_limit_per_pod`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00005`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00006`
- Constraint: `constraints.reliability.minimum_replicas`

### [BLOCKER] Deployment replica count is below profile minimum

The Deployment declares 1 replicas; the profile requires 2.

- Evidence: `obs-00007`
- Constraint: `constraints.reliability.minimum_replicas`

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00008`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00009`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00010`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references datatracker.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00011`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.aws.amazon.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00012`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references gateway-api.sigs.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00013`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00014`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00015`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00016`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tools.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00017`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00018`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references datatracker.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00019`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tools.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00020`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00021`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00022`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00023`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00024`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00025`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references acme-staging-v02.api.letsencrypt.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00026`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references cert-manager.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00027`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00028`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references datatracker.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00029`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.aws.amazon.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00030`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references gateway-api.sigs.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00031`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00032`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.rfc-editor.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00033`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references ca.domain.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00034`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references ocsp.int-x3.letsencrypt.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00035`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.vaultproject.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00036`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references vault.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00037`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.venafi.cloud, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00038`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references auth.apps.paloaltonetworks.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00039`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.strata.paloaltonetworks.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00040`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tpp.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00041`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references git.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00042`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references kubernetes.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00043`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references acme-staging-v02.api.letsencrypt.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00044`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references cert-manager.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00045`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references github.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00046`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references datatracker.ietf.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00047`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references docs.aws.amazon.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00048`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references gateway-api.sigs.k8s.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00049`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references golang.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00050`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.rfc-editor.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00051`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references ca.domain.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00052`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references ocsp.int-x3.letsencrypt.org, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00053`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references www.vaultproject.io, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00054`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references vault.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00055`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.venafi.cloud, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00056`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references auth.apps.paloaltonetworks.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00057`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references api.strata.paloaltonetworks.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00058`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

### [WARNING] Potential external network dependency

Rendered configuration references tpp.example.com, while the profile forbids public egress. Static presence does not prove a runtime dependency.

- Evidence: `obs-00059`
- Constraint: `constraints.networking.allow_public_egress`
- Limitation: Confirming a dependency requires a baseline/block/recovery runtime experiment, which has not run.

## Observation index

- `obs-00001` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-cainjector (container cert-manager-cainjector) — Container resource requests and limits were inspected.
- `obs-00002` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager (container cert-manager-controller) — Container resource requests and limits were inspected.
- `obs-00003` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-webhook (container cert-manager-webhook) — Container resource requests and limits were inspected.
- `obs-00004` [static_input] Job kubeproof-product/kubeproof-target-cert-manager-startupapicheck (container cert-manager-startupapicheck) — Container resource requests and limits were inspected.
- `obs-00005` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-cainjector — Deployment replica count was inspected.
- `obs-00006` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager — Deployment replica count was inspected.
- `obs-00007` [static_input] Deployment kubeproof-product/kubeproof-target-cert-manager-webhook — Deployment replica count was inspected.
- `obs-00008` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00009` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00010` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00011` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00012` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00013` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00014` [static_input] CustomResourceDefinition challenges.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00015` [static_input] CustomResourceDefinition orders.acme.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00016` [static_input] CustomResourceDefinition certificaterequests.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00017` [static_input] CustomResourceDefinition certificaterequests.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00018` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00019` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00020` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00021` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00022` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00023` [static_input] CustomResourceDefinition certificates.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00024` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00025` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00026` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00027` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00028` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00029` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00030` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00031` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00032` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00033` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00034` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00035` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00036` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00037` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00038` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00039` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00040` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00041` [static_input] CustomResourceDefinition clusterissuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00042` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00043` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00044` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00045` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00046` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00047` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00048` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00049` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00050` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00051` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00052` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00053` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00054` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00055` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00056` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00057` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00058` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00059` [static_input] CustomResourceDefinition issuers.cert-manager.io — Rendered configuration contains an external URL.
- `obs-00060` [static_input] evaluation — Rendered input was inspected for security and RBAC.
- `obs-00061` [static_input] evaluation — Rendered input was inspected for declared resources.
- `obs-00062` [static_input] evaluation — Rendered input was inspected for declared availability.
- `obs-00063` [static_input] evaluation — Rendered input was inspected for declared endpoints.
- `runtime-obs-00001` [runtime] evaluation — Helm installation and supported workload readiness were observed.
- `runtime-obs-00002` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-cainjector-6dcb649b59-4kcrq — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00003` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-6fc7cffd6f-54gwb — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00004` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-cainjector-6dcb649b59-4kcrq — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00005` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-webhook-6b9f56c466-m7kmh — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00006` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-6fc7cffd6f-54gwb — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00007` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-cainjector-6dcb649b59-4kcrq — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00008` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-webhook-6b9f56c466-m7kmh — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00009` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-6fc7cffd6f-54gwb — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00010` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-cainjector-6dcb649b59-4kcrq — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00011` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-6fc7cffd6f-54gwb — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00012` [runtime] Pod kubeproof-product/kubeproof-target-cert-manager-webhook-6b9f56c466-m7kmh — Kubernetes Metrics API returned a Pod CPU/memory sample.
- `runtime-obs-00013` [runtime] Deployment kubeproof-product/kubeproof-target-cert-manager — Deployment controller Pod replacement readiness was measured.
- `runtime-obs-00014` [runtime] Deployment kubeproof-product/kubeproof-target-cert-manager-cainjector — Deployment controller Pod replacement readiness was measured.

## Scope limitations

Runtime observations apply only to this disposable cluster and observation window.
A static URL or observed DNS query is not proof of a required network dependency. An absent security-context field is not proof of the image's runtime UID.
